package com.example.lisha.service

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import com.example.lisha.data.local.LishaPreferences
import com.example.lisha.engine.TtsManager
import com.example.lisha.model.NotificationAnnouncement
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class LishaNotificationListenerService : NotificationListenerService() {

    private lateinit var preferences: LishaPreferences

    override fun onCreate() {
        super.onCreate()
        preferences = LishaPreferences(applicationContext)
        _isNotificationListenerActive.value = true
        Log.d("LishaNotification", "Notification Listener Service created")
    }

    override fun onDestroy() {
        super.onDestroy()
        _isNotificationListenerActive.value = false
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        val extras = sbn.notification.extras ?: return
        val packageName = sbn.packageName ?: ""
        
        // Skip own notifications
        if (packageName == applicationContext.packageName) return

        val title = extras.getString(Notification.EXTRA_TITLE) ?: ""
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""

        if (title.isEmpty() && text.isEmpty()) return

        val isCall = packageName.contains("dialer", ignoreCase = true) ||
                packageName.contains("phone", ignoreCase = true) ||
                packageName.contains("telecom", ignoreCase = true) ||
                sbn.notification.category == Notification.CATEGORY_CALL

        val appName = when {
            packageName.contains("whatsapp", ignoreCase = true) -> "WhatsApp"
            packageName.contains("instagram", ignoreCase = true) -> "Instagram"
            packageName.contains("telegram", ignoreCase = true) -> "Telegram"
            packageName.contains("messaging", ignoreCase = true) -> "Messages"
            packageName.contains("phone", ignoreCase = true) || packageName.contains("dialer", ignoreCase = true) -> "Phone Call"
            else -> packageName.substringAfterLast('.')
        }

        val announcement = NotificationAnnouncement(
            appName = appName,
            sender = title,
            message = text,
            isCall = isCall
        )

        _latestAnnouncement.value = announcement
        _announcementHistory.value = listOf(announcement) + _announcementHistory.value.take(20)

        // Announce aloud if enabled
        if (isCall && preferences.callerAnnouncerEnabled) {
            val announcementText = if (preferences.announcerLanguage == "HINGLISH" || preferences.announcerLanguage == "HINDI") {
                "Aapko $title ka call aa raha hai"
            } else {
                "Incoming call from $title"
            }
            TtsManager.speak(applicationContext, announcementText)
        } else if (!isCall && preferences.messageAnnouncerEnabled && (appName in listOf("WhatsApp", "Instagram", "Telegram", "Messages"))) {
            val speech = if (preferences.announcerLanguage == "HINGLISH" || preferences.announcerLanguage == "HINDI") {
                "$appName par $title se naya message: $text"
            } else {
                "New message on $appName from $title: $text"
            }
            TtsManager.speak(applicationContext, speech)
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        // Notification dismissed
    }

    companion object {
        private val _isNotificationListenerActive = MutableStateFlow(false)
        val isNotificationListenerActive: StateFlow<Boolean> = _isNotificationListenerActive.asStateFlow()

        private val _latestAnnouncement = MutableStateFlow<NotificationAnnouncement?>(null)
        val latestAnnouncement: StateFlow<NotificationAnnouncement?> = _latestAnnouncement.asStateFlow()

        private val _announcementHistory = MutableStateFlow<List<NotificationAnnouncement>>(emptyList())
        val announcementHistory: StateFlow<List<NotificationAnnouncement>> = _announcementHistory.asStateFlow()

        fun postSimulatedAnnouncement(announcement: NotificationAnnouncement) {
            _latestAnnouncement.value = announcement
            _announcementHistory.value = listOf(announcement) + _announcementHistory.value.take(20)
        }
    }
}
