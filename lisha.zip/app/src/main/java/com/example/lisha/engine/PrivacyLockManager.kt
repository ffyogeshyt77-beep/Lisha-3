package com.example.lisha.engine

import android.content.Context
import com.example.lisha.data.local.LishaPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object PrivacyLockManager {

    private val _isAuthModalOpen = MutableStateFlow(false)
    val isAuthModalOpen: StateFlow<Boolean> = _isAuthModalOpen.asStateFlow()

    private val _pendingAuthReason = MutableStateFlow("")
    val pendingAuthReason: StateFlow<String> = _pendingAuthReason.asStateFlow()

    private var pendingOnSuccessAction: (() -> Unit)? = null
    private var lastUnlockedTimestamp: Long = 0
    private const val UNLOCK_GRACE_PERIOD_MS = 60_000L // 1 minute session grace

    fun isProtectedAction(context: Context, targetOrAppName: String): Boolean {
        val prefs = LishaPreferences(context)
        if (!prefs.privacyLockEnabled) return false

        val lower = targetOrAppName.lowercase()
        val sensitiveKeywords = listOf("bank", "paytm", "gpay", "google pay", "phonepe", "upi", "wallet", "settings", "password", "pin", "gallery", "photos")
        if (sensitiveKeywords.any { lower.contains(it) }) {
            return true
        }

        val packages = prefs.protectedPackages
        return packages.any { lower.contains(it.lowercase()) }
    }

    fun isCurrentlyUnlocked(): Boolean {
        return (System.currentTimeMillis() - lastUnlockedTimestamp) < UNLOCK_GRACE_PERIOD_MS
    }

    fun requestAuthentication(
        reason: String,
        onSuccess: () -> Unit
    ) {
        if (isCurrentlyUnlocked()) {
            onSuccess.invoke()
            return
        }
        _pendingAuthReason.value = reason
        pendingOnSuccessAction = onSuccess
        _isAuthModalOpen.value = true
    }

    fun verifyPin(context: Context, enteredPin: String): Boolean {
        val prefs = LishaPreferences(context)
        val validPin = prefs.pinCode
        if (enteredPin == validPin) {
            lastUnlockedTimestamp = System.currentTimeMillis()
            _isAuthModalOpen.value = false
            pendingOnSuccessAction?.invoke()
            pendingOnSuccessAction = null
            return true
        }
        return false
    }

    fun cancelAuthentication() {
        _isAuthModalOpen.value = false
        pendingOnSuccessAction = null
    }

    fun simulateBiometricSuccess() {
        lastUnlockedTimestamp = System.currentTimeMillis()
        _isAuthModalOpen.value = false
        pendingOnSuccessAction?.invoke()
        pendingOnSuccessAction = null
    }
}
