package com.example.lisha.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.LishaBorder
import com.example.ui.theme.LishaElectricViolet
import com.example.ui.theme.LishaMintSuccess
import com.example.ui.theme.LishaNeonCyan
import com.example.ui.theme.LishaObsidian
import com.example.ui.theme.LishaSurface
import com.example.ui.theme.LishaSurfaceHigh
import com.example.ui.theme.LishaTextPrimary
import com.example.ui.theme.LishaTextSecondary

@Composable
fun LishaTopBar(
    batteryLevel: Int,
    ramUsedMb: Long,
    isAccessibilityOn: Boolean,
    onSecurityClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = LishaObsidian,
        tonalElevation = 4.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Brand & Agent Identity
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(LishaSurfaceHigh)
                        .padding(2.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.lisha_icon),
                        contentDescription = "Lisha AI Agent Logo",
                        modifier = Modifier.fillMaxWidth().clip(CircleShape)
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "LISHA",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Black,
                                letterSpacing = 2.sp,
                                color = LishaTextPrimary
                            )
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(LishaNeonCyan.copy(alpha = 0.15f))
                                .padding(horizontal = 5.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "v2.6 AUTONOMOUS",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = LishaNeonCyan,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 9.sp
                                )
                            )
                        }
                    }
                    Text(
                        text = if (isAccessibilityOn) "Accessibility Automation Online" else "Standard Automation Active",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = if (isAccessibilityOn) LishaMintSuccess else LishaTextSecondary,
                            fontSize = 11.sp
                        )
                    )
                }
            }

            // Quick Telemetry & Status Badges
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Battery telemetry
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = LishaSurfaceHigh,
                    border = androidx.compose.foundation.BorderStroke(1.dp, LishaBorder)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.BatteryFull,
                            contentDescription = "Battery",
                            tint = LishaMintSuccess,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "$batteryLevel%",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = LishaTextPrimary,
                                fontWeight = FontWeight.SemiBold
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Security & Privacy quick action
                IconButton(
                    onClick = onSecurityClick,
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(LishaSurfaceHigh)
                        .testTag("security_header_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = "Security Vault",
                        tint = LishaElectricViolet,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}
