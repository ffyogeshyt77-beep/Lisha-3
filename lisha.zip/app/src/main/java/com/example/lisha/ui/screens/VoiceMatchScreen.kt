package com.example.lisha.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.lisha.data.local.LishaPreferences
import com.example.lisha.engine.TtsManager
import com.example.lisha.engine.VoiceMatchEngine
import com.example.lisha.viewmodel.LishaViewModel
import com.example.ui.theme.LishaAlertRed
import com.example.ui.theme.LishaBorder
import com.example.ui.theme.LishaElectricViolet
import com.example.ui.theme.LishaMintSuccess
import com.example.ui.theme.LishaNeonCyan
import com.example.ui.theme.LishaObsidian
import com.example.ui.theme.LishaPurpleGlow
import com.example.ui.theme.LishaSurface
import com.example.ui.theme.LishaSurfaceHigh
import com.example.ui.theme.LishaTextPrimary
import com.example.ui.theme.LishaTextSecondary

@Composable
fun VoiceMatchScreen(
    viewModel: LishaViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val prefs = remember { LishaPreferences(context) }
    val voiceState by VoiceMatchEngine.voiceState.collectAsState()
    val isCalibrating by VoiceMatchEngine.isCalibrating.collectAsState()
    val calibProgress by VoiceMatchEngine.calibrationProgress.collectAsState()

    var strictVoiceMatch by remember { mutableStateOf(prefs.voiceMatchStrict) }
    var privacyLockActive by remember { mutableStateOf(prefs.privacyLockEnabled) }
    var pinCodeInput by remember { mutableStateOf(prefs.pinCode) }

    val sensitiveApps = listOf(
        Pair("Google Pay", "com.google.android.apps.nbu.paisa.user"),
        Pair("PhonePe", "com.phonepe.app"),
        Pair("Paytm", "net.one97.paytm"),
        Pair("Device Settings", "com.android.settings"),
        Pair("WhatsApp Messages", "com.whatsapp"),
        Pair("Gallery & Photos", "com.google.android.apps.photos")
    )
    var selectedProtectedPackages by remember { mutableStateOf(prefs.protectedPackages) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(LishaObsidian)
            .padding(16.dp)
            .testTag("voice_match_security_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "SECURITY & VOICE MATCH",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Black,
                    color = LishaTextPrimary,
                    letterSpacing = 1.sp
                )
            )
            Text(
                text = "Biometric speaker recognition ensures Lisha ONLY responds to the authorized owner. Privacy Lock guards financial and confidential apps.",
                style = MaterialTheme.typography.bodySmall.copy(color = LishaTextSecondary)
            )
        }

        // Speaker Recognition Status Card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = LishaSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, LishaBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(LishaMintSuccess.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.RecordVoiceOver, contentDescription = null, tint = LishaMintSuccess, modifier = Modifier.size(20.dp))
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "VOICE MATCH PROFILE",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                                Text(
                                    text = if (voiceState.isEnrolled) "Enrolled: ${prefs.ownerName} (Acoustic Match Active)" else "Profile Not Calibrated",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = if (voiceState.isEnrolled) LishaMintSuccess else LishaAlertRed,
                                        fontSize = 11.sp
                                    )
                                )
                            }
                        }

                        Switch(
                            checked = strictVoiceMatch,
                            onCheckedChange = {
                                strictVoiceMatch = it
                                prefs.voiceMatchStrict = it
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = LishaMintSuccess,
                                checkedTrackColor = LishaMintSuccess.copy(alpha = 0.3f)
                            ),
                            modifier = Modifier.testTag("strict_voice_match_toggle")
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "Confidence Match Score: ${(voiceState.lastMatchScore * 100).toInt()}%",
                        style = MaterialTheme.typography.bodySmall.copy(color = Color.White, fontWeight = FontWeight.SemiBold)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    LinearProgressIndicator(
                        progress = { voiceState.lastMatchScore },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = if (voiceState.lastMatchScore >= 0.8f) LishaMintSuccess else LishaAlertRed,
                        trackColor = LishaSurfaceHigh
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Harmonics: ${voiceState.enrolledPitchRange}",
                        style = MaterialTheme.typography.bodySmall.copy(color = LishaTextSecondary, fontSize = 11.sp)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                VoiceMatchEngine.startCalibration()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = LishaNeonCyan),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("start_calibration_button")
                        ) {
                            Icon(Icons.Default.Mic, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Calibrate Voice (3 Steps)", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }

                        Button(
                            onClick = {
                                val match = VoiceMatchEngine.verifyVoiceSample(context, "Test Sample")
                                val speech = if (match) "Voice verified. Hello Commander!" else "Voice mismatch detected."
                                TtsManager.speak(context, speech)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = LishaSurfaceHigh),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("test_voice_match_button")
                        ) {
                            Text("Test Match Ping", color = LishaNeonCyan, fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        // Voice Calibration Wizard Dialog
        if (isCalibrating) {
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = LishaSurfaceHigh),
                    border = androidx.compose.foundation.BorderStroke(1.dp, LishaNeonCyan),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Calibrating Voice Print: Step ${calibProgress + 1} of 3",
                            style = MaterialTheme.typography.titleMedium.copy(color = LishaNeonCyan, fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Say clearly: 'Hello Lisha, activate autonomous agent'",
                            style = MaterialTheme.typography.bodyMedium.copy(color = Color.White, fontStyle = androidx.compose.ui.text.font.FontStyle.Italic)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = {
                                VoiceMatchEngine.recordCalibrationStep(calibProgress + 1)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = LishaNeonCyan),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Record Audio Sample ${calibProgress + 1}", color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Privacy Lock Guard Card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = LishaSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, LishaBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Shield, contentDescription = null, tint = LishaAlertRed, modifier = Modifier.size(22.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "PRIVACY LOCK GUARD",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }

                        Switch(
                            checked = privacyLockActive,
                            onCheckedChange = {
                                privacyLockActive = it
                                prefs.privacyLockEnabled = it
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = LishaAlertRed,
                                checkedTrackColor = LishaAlertRed.copy(alpha = 0.3f)
                            ),
                            modifier = Modifier.testTag("privacy_lock_toggle")
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Intercepts automated commands when opening sensitive apps and requires Biometric or PIN challenge before execution.",
                        style = MaterialTheme.typography.bodySmall.copy(color = LishaTextSecondary)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = pinCodeInput,
                        onValueChange = {
                            if (it.length <= 4) {
                                pinCodeInput = it
                                prefs.pinCode = it
                            }
                        },
                        label = { Text("Agent PIN Code (Default: 1234)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = LishaAlertRed,
                            unfocusedBorderColor = LishaBorder,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "PROTECTED SENSITIVE APPS:",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = LishaTextSecondary,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    sensitiveApps.forEach { (appName, pkg) ->
                        val isChecked = selectedProtectedPackages.contains(pkg)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = isChecked,
                                onCheckedChange = { checked ->
                                    val newSet = selectedProtectedPackages.toMutableSet()
                                    if (checked) newSet.add(pkg) else newSet.remove(pkg)
                                    selectedProtectedPackages = newSet
                                    prefs.protectedPackages = newSet
                                },
                                colors = CheckboxDefaults.colors(
                                    checkedColor = LishaAlertRed,
                                    checkmarkColor = Color.White
                                )
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = appName, style = MaterialTheme.typography.bodyMedium.copy(color = Color.White))
                        }
                    }
                }
            }
        }
    }
}
