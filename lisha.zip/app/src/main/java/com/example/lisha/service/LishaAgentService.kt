package com.example.lisha.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.lisha.data.local.LishaPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class LishaAgentService : Service() {

    private lateinit var preferences: LishaPreferences
    private var screenStateReceiver: BroadcastReceiver? = null

    override fun onCreate() {
        super.onCreate()
        preferences = LishaPreferences(applicationContext)
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildForegroundNotification("Lisha is active • Listening for wake-word"))
        registerScreenStateObserver()
        _isAgentServiceRunning.value = true
        Log.d("LishaAgentService", "Lisha Foreground Agent Service started")
    }

    private fun registerScreenStateObserver() {
        screenStateReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                when (intent?.action) {
                    Intent.ACTION_SCREEN_OFF -> {
                        _isScreenSleeping.value = true
                        if (preferences.smartBatteryOptimization) {
                            Log.d("LishaAgentService", "Screen OFF: Entering ultra-low power standby mode (Zero battery drain)")
                        }
                    }
                    Intent.ACTION_SCREEN_ON -> {
                        _isScreenSleeping.value = false
                        Log.d("LishaAgentService", "Screen ON: Resuming full-speed acoustic and dual-engine worker readiness")
                    }
                }
            }
        }
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
        }
        registerReceiver(screenStateReceiver, filter)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Lisha Autonomous Agent Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps Lisha wake-word engine and smart caller announcer active"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun buildForegroundNotification(contentText: String): Notification {
        val launchIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            launchIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Lisha AI Agent")
            .setContentText(contentText)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        screenStateReceiver?.let {
            try {
                unregisterReceiver(it)
            } catch (e: Exception) {
                Log.e("LishaAgentService", "Error unregistering receiver", e)
            }
        }
        _isAgentServiceRunning.value = false
    }

    companion object {
        const val CHANNEL_ID = "lisha_autonomous_agent_channel"
        const val NOTIFICATION_ID = 1001

        private val _isAgentServiceRunning = MutableStateFlow(false)
        val isAgentServiceRunning: StateFlow<Boolean> = _isAgentServiceRunning.asStateFlow()

        private val _isScreenSleeping = MutableStateFlow(false)
        val isScreenSleeping: StateFlow<Boolean> = _isScreenSleeping.asStateFlow()
    }
}
