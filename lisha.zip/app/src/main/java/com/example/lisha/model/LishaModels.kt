package com.example.lisha.model

enum class ActionType {
    OPEN_APP,
    TOGGLE_SETTING,
    SCROLL,
    CLICK_NODE,
    TYPE_TEXT,
    SCREEN_LOCK,
    SAVE_MEMORY,
    RECALL_MEMORY,
    ANNOUNCE,
    MAKE_CALL,
    SEND_MESSAGE,
    CUSTOM_INTENT
}

enum class StepStatus {
    PENDING,
    RUNNING,
    COMPLETED,
    FAILED,
    SKIPPED
}

data class TaskStep(
    val id: String,
    val title: String,
    val description: String,
    val actionType: ActionType,
    val target: String,
    val status: StepStatus = StepStatus.PENDING,
    val executionLog: String = ""
)

data class TaskQueue(
    val queueId: String,
    val originalPrompt: String,
    val steps: List<TaskStep>,
    val currentStepIndex: Int = 0,
    val isRunning: Boolean = false,
    val completedSuccessfully: Boolean = false,
    val errorMessage: String? = null
)

enum class IntentType {
    APP_CONTROL,
    MULTI_STEP,
    SAVE_MEMORY,
    RECALL_MEMORY,
    SYSTEM_TOGGLE,
    CALL_OR_MESSAGE,
    SCREEN_VISION,
    GENERAL_QA,
    UNKNOWN
}

data class ParsedCommand(
    val rawText: String,
    val intentType: IntentType,
    val confidence: Float = 0.95f,
    val steps: List<TaskStep> = emptyList(),
    val targetPackage: String? = null,
    val memoryKey: String? = null,
    val memoryValue: String? = null,
    val requiresPrivacyAuth: Boolean = false,
    val directSpokenResponse: String? = null
)

enum class WorkerState {
    IDLE,
    PROCESSING,
    SUCCESS,
    ERROR
}

data class DualEngineStatus(
    val fastLiteWorker: String = "Gemini 2.5 Flash",
    val fastLiteState: WorkerState = WorkerState.IDLE,
    val fastLiteLatencyMs: Long = 180,
    val fastLiteCallCount: Int = 14,
    val reasoningWorker: String = "Gemini 2.5 Pro",
    val reasoningState: WorkerState = WorkerState.IDLE,
    val reasoningLatencyMs: Long = 420,
    val reasoningCallCount: Int = 8,
    val isOfflineFallbackActive: Boolean = false,
    val lastRouteReason: String = "Fast Lite handled wake-word and intent routing"
)

data class VoiceMatchState(
    val isEnrolled: Boolean = true,
    val enrolledSpeakerName: String = "Owner",
    val calibrationSampleCount: Int = 3,
    val lastMatchScore: Float = 0.94f,
    val isCurrentVoiceAuthorized: Boolean = true,
    val enrolledPitchRange: String = "118 Hz - 142 Hz (Harmonic Match)"
)

data class NotificationAnnouncement(
    val id: Long = System.currentTimeMillis(),
    val appName: String,
    val sender: String,
    val message: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isCall: Boolean = false
)
