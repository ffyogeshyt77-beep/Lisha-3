package com.example.lisha.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class LishaAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        _isAccessibilityActive.value = true
        Log.d("LishaAccessibility", "Lisha Accessibility Service connected successfully")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val packageName = event.packageName?.toString() ?: ""
        _currentForegroundPackage.value = packageName

        // Inspect window content changes
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val title = event.text.joinToString(" ")
            if (title.isNotEmpty()) {
                _currentScreenTitle.value = title
            }
        }
    }

    override fun onInterrupt() {
        Log.w("LishaAccessibility", "Lisha Accessibility Service interrupted")
    }

    override fun onDestroy() {
        super.onDestroy()
        if (instance == this) {
            instance = null
            _isAccessibilityActive.value = false
        }
    }

    companion object {
        private var instance: LishaAccessibilityService? = null

        private val _isAccessibilityActive = MutableStateFlow(false)
        val isAccessibilityActive: StateFlow<Boolean> = _isAccessibilityActive.asStateFlow()

        private val _currentForegroundPackage = MutableStateFlow("com.example")
        val currentForegroundPackage: StateFlow<String> = _currentForegroundPackage.asStateFlow()

        private val _currentScreenTitle = MutableStateFlow("Home Screen")
        val currentScreenTitle: StateFlow<String> = _currentScreenTitle.asStateFlow()

        fun isConnected(): Boolean = instance != null

        fun lockScreen(): Boolean {
            return instance?.performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN) ?: false
        }

        fun goHome(): Boolean {
            return instance?.performGlobalAction(GLOBAL_ACTION_HOME) ?: false
        }

        fun goBack(): Boolean {
            return instance?.performGlobalAction(GLOBAL_ACTION_BACK) ?: false
        }

        fun openRecents(): Boolean {
            return instance?.performGlobalAction(GLOBAL_ACTION_RECENTS) ?: false
        }

        fun openNotifications(): Boolean {
            return instance?.performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS) ?: false
        }

        fun findAndClick(targetText: String): Boolean {
            val root = instance?.rootInActiveWindow ?: return false
            val nodes = root.findAccessibilityNodeInfosByText(targetText)
            if (nodes.isNotEmpty()) {
                for (node in nodes) {
                    if (node.isClickable && node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                        return true
                    }
                    // Try parent clickable
                    var parent = node.parent
                    while (parent != null) {
                        if (parent.isClickable && parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                            return true
                        }
                        parent = parent.parent
                    }
                }
            }
            return false
        }

        fun inputText(text: String): Boolean {
            val root = instance?.rootInActiveWindow ?: return false
            val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            if (focused != null && focused.isEditable) {
                val args = Bundle().apply {
                    putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
                }
                return focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
            }
            return false
        }

        fun extractVisibleScreenElements(): List<String> {
            val elements = mutableListOf<String>()
            val root = instance?.rootInActiveWindow ?: return listOf("Screen node tree unavailable (Permission required)")
            
            fun traverse(node: AccessibilityNodeInfo?) {
                if (node == null) return
                val text = node.text?.toString()?.trim()
                val desc = node.contentDescription?.toString()?.trim()
                if (!text.isNullOrEmpty()) elements.add(text)
                else if (!desc.isNullOrEmpty()) elements.add(desc)

                for (i in 0 until node.childCount) {
                    traverse(node.getChild(i))
                }
            }
            traverse(root)
            return if (elements.isEmpty()) listOf("Screen is blank or non-textual") else elements.take(25)
        }
    }
}
