package com.example.lisha.engine

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import com.example.lisha.data.local.LishaPreferences
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File
import java.io.FileOutputStream
import java.util.Locale
import java.util.concurrent.TimeUnit

object TtsManager {
    private var tts: TextToSpeech? = null
    private var isInitialized = false
    private val scope = CoroutineScope(Dispatchers.IO)
    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _speakingSpeechText = MutableStateFlow("")
    val speakingSpeechText: StateFlow<String> = _speakingSpeechText.asStateFlow()

    private val _waveformAmplitudes = MutableStateFlow(listOf(0.2f, 0.4f, 0.6f, 0.3f, 0.5f, 0.7f, 0.4f, 0.2f))
    val waveformAmplitudes: StateFlow<List<Float>> = _waveformAmplitudes.asStateFlow()

    fun init(context: Context) {
        if (tts != null) return
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.ENGLISH
                tts?.setSpeechRate(1.05f)
                tts?.setPitch(1.02f)
                isInitialized = true
                Log.d("TtsManager", "System TextToSpeech initialized")
            } else {
                Log.e("TtsManager", "TTS initialization failed: $status")
            }
        }

        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                _isSpeaking.value = true
                startWaveformSimulation()
            }

            override fun onDone(utteranceId: String?) {
                _isSpeaking.value = false
            }

            override fun onError(utteranceId: String?) {
                _isSpeaking.value = false
            }
        })
    }

    fun speak(context: Context, text: String, onComplete: (() -> Unit)? = null) {
        _speakingSpeechText.value = text
        val prefs = LishaPreferences(context)

        // Try ElevenLabs if selected & key provided
        if (prefs.ttsEngineType == "ELEVENLABS" && prefs.elevenLabsApiKey.isNotBlank()) {
            scope.launch {
                val success = speakWithElevenLabs(context, text, prefs.elevenLabsApiKey, prefs.elevenLabsVoiceId)
                if (!success) {
                    // Graceful fallback to System TTS
                    speakWithSystemTts(context, text, onComplete)
                } else {
                    onComplete?.invoke()
                }
            }
        } else {
            speakWithSystemTts(context, text, onComplete)
        }
    }

    private fun speakWithSystemTts(context: Context, text: String, onComplete: (() -> Unit)?) {
        if (!isInitialized) {
            init(context)
        }
        val utteranceId = "lisha_speech_${System.currentTimeMillis()}"
        _isSpeaking.value = true
        startWaveformSimulation()

        val result = tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
        if (result != TextToSpeech.SUCCESS) {
            Log.w("TtsManager", "System TTS queued with non-success code $result")
        }
        scope.launch {
            // Safety timeout for speech animation
            val estDurationMs = (text.length * 75L).coerceIn(1200L, 8000L)
            delay(estDurationMs)
            _isSpeaking.value = false
            onComplete?.invoke()
        }
    }

    private suspend fun speakWithElevenLabs(
        context: Context,
        text: String,
        apiKey: String,
        voiceId: String
    ): Boolean {
        return try {
            val url = "https://api.elevenlabs.io/v1/text-to-speech/$voiceId"
            val jsonBody = """
                {
                  "text": ${escapeJson(text)},
                  "model_id": "eleven_multilingual_v2",
                  "voice_settings": {
                    "stability": 0.5,
                    "similarity_boost": 0.8
                  }
                }
            """.trimIndent()

            val request = Request.Builder()
                .url(url)
                .addHeader("xi-api-key", apiKey)
                .addHeader("Content-Type", "application/json")
                .post(jsonBody.toRequestBody("application/json".toMediaType()))
                .build()

            val response = okHttpClient.newCall(request).execute()
            if (response.isSuccessful) {
                val bytes = response.body?.bytes() ?: return false
                val tempFile = File.createTempFile("lisha_tts_", ".mp3", context.cacheDir)
                FileOutputStream(tempFile).use { it.write(bytes) }

                val player = MediaPlayer().apply {
                    setAudioAttributes(
                        AudioAttributes.Builder()
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .setUsage(AudioAttributes.USAGE_ASSISTANT)
                            .build()
                    )
                    setDataSource(tempFile.absolutePath)
                    prepare()
                }

                _isSpeaking.value = true
                startWaveformSimulation()
                player.start()
                player.setOnCompletionListener {
                    _isSpeaking.value = false
                    tempFile.delete()
                    player.release()
                }
                true
            } else {
                Log.w("TtsManager", "ElevenLabs error code: ${response.code}")
                false
            }
        } catch (e: Exception) {
            Log.e("TtsManager", "ElevenLabs failed, falling back to System TTS", e)
            false
        }
    }

    private fun startWaveformSimulation() {
        scope.launch {
            val base = listOf(0.3f, 0.6f, 0.9f, 0.4f, 0.8f, 0.5f, 0.7f, 0.3f)
            while (_isSpeaking.value) {
                _waveformAmplitudes.value = base.map { (it * (0.6f + Math.random().toFloat() * 0.8f)).coerceIn(0.1f, 1.0f) }
                delay(90)
            }
            _waveformAmplitudes.value = listOf(0.15f, 0.2f, 0.25f, 0.2f, 0.15f, 0.18f, 0.22f, 0.15f)
        }
    }

    fun stop() {
        tts?.stop()
        _isSpeaking.value = false
    }

    private fun escapeJson(str: String): String {
        return "\"" + str.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n") + "\""
    }
}
