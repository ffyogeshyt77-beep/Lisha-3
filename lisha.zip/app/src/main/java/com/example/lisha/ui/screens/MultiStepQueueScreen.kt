package com.example.lisha.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.lisha.model.StepStatus
import com.example.lisha.viewmodel.LishaViewModel
import com.example.ui.theme.LishaAlertRed
import com.example.ui.theme.LishaBorder
import com.example.ui.theme.LishaElectricViolet
import com.example.ui.theme.LishaMintSuccess
import com.example.ui.theme.LishaNeonCyan
import com.example.ui.theme.LishaObsidian
import com.example.ui.theme.LishaSurface
import com.example.ui.theme.LishaSurfaceHigh
import com.example.ui.theme.LishaTextPrimary
import com.example.ui.theme.LishaTextSecondary

@Composable
fun MultiStepQueueScreen(
    viewModel: LishaViewModel,
    modifier: Modifier = Modifier
) {
    val activeQueue by viewModel.activeTaskQueue.collectAsState()
    val taskHistory by viewModel.taskHistory.collectAsState()
    var customChainInput by remember { mutableStateOf("") }

    val sampleChains = listOf(
        "WiFi chalu karo, Instagram kholo, aur message bhejo",
        "Torch on karo aur Camera launch karo",
        "Volume badhao, YouTube open karo, aur Phone lock karo"
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(LishaObsidian)
            .padding(16.dp)
            .testTag("multi_step_queue_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "MULTI-STEP TASK QUEUE",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Black,
                    color = LishaTextPrimary,
                    letterSpacing = 1.sp
                )
            )
            Text(
                text = "Chain multiple autonomous instructions in one sentence. Lisha breaks down and executes them sequentially.",
                style = MaterialTheme.typography.bodySmall.copy(color = LishaTextSecondary)
            )
        }

        // Custom Chain Creator
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = LishaSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, LishaBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "NEW SEQUENTIAL TASK CHAIN",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = LishaNeonCyan,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = customChainInput,
                        onValueChange = { customChainInput = it },
                        placeholder = { Text("E.g. Turn on flashlight, open camera, and volume up…", fontSize = 13.sp) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("chain_input_field"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = LishaNeonCyan,
                            unfocusedBorderColor = LishaBorder,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = {
                            if (customChainInput.isNotBlank()) {
                                viewModel.executeUserCommand(customChainInput)
                                customChainInput = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = LishaNeonCyan),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp)
                            .testTag("run_chain_button")
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.Black)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Execute Task Pipeline", color = Color.Black, fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Quick presets:",
                        style = MaterialTheme.typography.labelSmall.copy(color = LishaTextSecondary)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    sampleChains.forEach { preset ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = LishaSurfaceHigh,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = preset,
                                    style = MaterialTheme.typography.bodySmall.copy(color = Color.White),
                                    modifier = Modifier.weight(1f)
                                )
                                Button(
                                    onClick = { viewModel.executeUserCommand(preset) },
                                    colors = ButtonDefaults.buttonColors(containerColor = LishaElectricViolet),
                                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Text("Run", fontSize = 11.sp, color = Color.White)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Active Pipeline Visualizer
        if (activeQueue != null) {
            item {
                val q = activeQueue!!
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = LishaSurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, LishaNeonCyan.copy(alpha = 0.5f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("active_pipeline_card")
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "ACTIVE PIPELINE PROGRESS",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    color = LishaNeonCyan,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                            if (q.isRunning) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    strokeWidth = 2.dp,
                                    color = LishaNeonCyan
                                )
                            } else {
                                Text(
                                    text = if (q.completedSuccessfully) "COMPLETED" else "STOPPED",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = if (q.completedSuccessfully) LishaMintSuccess else LishaAlertRed,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "\"${q.originalPrompt}\"",
                            style = MaterialTheme.typography.bodySmall.copy(color = LishaTextSecondary, fontStyle = androidx.compose.ui.text.font.FontStyle.Italic)
                        )
                        Spacer(modifier = Modifier.height(14.dp))

                        q.steps.forEachIndexed { idx, step ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(
                                            when (step.status) {
                                                StepStatus.COMPLETED -> LishaMintSuccess
                                                StepStatus.RUNNING -> LishaNeonCyan
                                                StepStatus.FAILED -> LishaAlertRed
                                                StepStatus.PENDING -> LishaSurfaceHigh
                                                StepStatus.SKIPPED -> LishaSurfaceHigh
                                            }
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    when (step.status) {
                                        StepStatus.COMPLETED -> Icon(Icons.Default.Check, contentDescription = null, tint = Color.Black, modifier = Modifier.size(18.dp))
                                        StepStatus.RUNNING -> CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = Color.Black)
                                        StepStatus.FAILED -> Icon(Icons.Default.Close, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                                        else -> Text("${idx + 1}", color = LishaTextSecondary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    }
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = step.title,
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            color = if (step.status == StepStatus.RUNNING) LishaNeonCyan else Color.White,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    )
                                    Text(
                                        text = "${step.actionType.name}: ${step.target}",
                                        style = MaterialTheme.typography.bodySmall.copy(color = LishaTextSecondary, fontSize = 11.sp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Execution History Log (Stored in Room)
        item {
            Text(
                text = "RECENT TASK HISTORY (ROOM DB)",
                style = MaterialTheme.typography.labelSmall.copy(
                    color = LishaTextSecondary,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.2.sp
                )
            )
        }

        if (taskHistory.isEmpty()) {
            item {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = LishaSurface,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(modifier = Modifier.padding(24.dp), contentAlignment = Alignment.Center) {
                        Text("No task logs yet. Execute your first command above!", color = LishaTextSecondary, fontSize = 12.sp)
                    }
                }
            }
        } else {
            items(taskHistory) { task ->
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = LishaSurface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, LishaBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = task.originalPrompt,
                                style = MaterialTheme.typography.bodyMedium.copy(color = Color.White, fontWeight = FontWeight.SemiBold)
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "${task.stepsSummary} • ${task.engineName} (${task.durationMs}ms)",
                                style = MaterialTheme.typography.bodySmall.copy(color = LishaTextSecondary, fontSize = 11.sp)
                            )
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(LishaMintSuccess.copy(alpha = 0.15f))
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = task.status,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = LishaMintSuccess,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}
