package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val LishaObsidian = Color(0xFF070913)
val LishaSurface = Color(0xFF0E1326)
val LishaSurfaceVariant = Color(0xFF161E38)
val LishaSurfaceHigh = Color(0xFF1E284A)
val LishaBorder = Color(0xFF283664)

val LishaNeonCyan = Color(0xFF00E5FF)
val LishaElectricViolet = Color(0xFF9D4EDD)
val LishaPurpleGlow = Color(0xFFC77DFF)
val LishaMintSuccess = Color(0xFF00E676)
val LishaAlertRed = Color(0xFFFF3D71)
val LishaAmber = Color(0xFFFFB703)

val LishaTextPrimary = Color(0xFFF1F5F9)
val LishaTextSecondary = Color(0xFF94A3B8)
val LishaTextTertiary = Color(0xFF64748B)
